
# UniTender - Permanent Deployment Guide

## Permanent Solution - GitHub + Render + Vercel (Free Lifetime)

### Step 1: GitHub Pe Code Daalo

1. github.com pe jao - New Repository banao:
   - Name: unitender-permanent
   - Public rakho

2. Is folder ko push karo:
   ```
   git init
   git add .
   git commit -m "Initial commit - permanent realtime"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/unitender-permanent.git
   git push -u origin main
   ```

### Step 2: Backend Deploy Render Pe (Permanent)

1. render.com pe jao - GitHub se Sign Up
2. New + -> Web Service
3. Apna repo select karo: unitender-permanent
4. Settings:
   - Root Directory: backend
   - Build Command: npm install
   - Start Command: npm start
   - Plan: Free
5. Environment Variables (optional):
   - MONGODB_URI: tumhara Atlas URL (agar permanent DB chahiye)
   - JWT_SECRET: unitender_secret
6. Deploy -> 5 min me URL milega: https://unitender-backend-xyz.onrender.com
7. Ye URL copy kar lo!

### Step 3: Frontend Me Backend URL Update Karo

frontend/index.html me ja ke:
```javascript
const RENDER_BACKEND_URL = 'https://unitender-backend-xyz.onrender.com'; // Yaha apna Render URL daalo
```
Change karke GitHub pe push karo:
```
git add .
git commit -m "Update backend URL"
git push
```

### Step 4: Frontend Deploy Vercel Pe (Permanent)

1. vercel.com pe jao - GitHub se login
2. Add New Project -> unitender-permanent repo select karo
3. Root Directory: frontend
4. Deploy -> URL milega: https://unitender.vercel.app

### Done! Permanent Link Ready!

- Backend: https://unitender-backend-xyz.onrender.com
- Frontend: https://unitender.vercel.app

Ye link GF ko, friends ko, teacher ko kahin se bhi bhejo - alag network pe bhi real-time notification ayega!

### Real-time Kaise Kaam Karega:

- Laptop pe Organization login
- GF ke phone pe (alag city) Vendor register
- Tumhare laptop pe turant notification: "🔥 New vendor Rahul registered!"

No same WiFi needed! Worldwide works!

### Local Network Pe Bhi Kaam Karega?

Ha! Agar same WiFi pe ho to:
- http://192.168.0.105:5000 (backend)
- http://192.168.0.105:5500 (frontend)
Bhi kaam karega - code auto-detect karta hai!

### MongoDB Atlas Kaise Add Kare (Optional Permanent DB):

1. Atlas me Network Access -> 0.0.0.0/0 add karo (already kiya)
2. Render me Environment Variable me MONGODB_URI daalo
3. Redeploy - data permanent save hoga!

### Troubleshooting:

- Render free tier 15 min inactive pe sleep hota hai - first request 30 sec lagega
- Vercel always active rehta hai
- Socket.io dono pe kaam karta hai
